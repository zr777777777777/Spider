import os
import time
import re
import hashlib
import random
import requests
import numpy as np
from io import BytesIO
from PIL import Image
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms

class AnimeClassifier(nn.Module):
    """改进的CNN模型用于区分动画图像和真实图像"""
    def __init__(self):
        super(AnimeClassifier, self).__init__()
        # 第一个卷积块
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        # 第二个卷积块
        self.conv2 = nn.Sequential(
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        # 第三个卷积块
        self.conv3 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        # 第四个卷积块
        self.conv4 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        # 全连接层: 图像大小经过4次池化后为8x8
        self.fc1 = nn.Linear(256 * 8 * 8, 512)
        self.bn1 = nn.BatchNorm1d(512)
        self.fc2 = nn.Linear(512, 128)
        self.bn2 = nn.BatchNorm1d(128)
        self.fc3 = nn.Linear(128, 2)  # 二分类：0为动画，1为真实图像
        
        self.dropout = nn.Dropout(0.5)
        
        # 权重初始化
        self._initialize_weights()
    
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                # Kaiming/He 初始化
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        # 四个卷积块
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        
        # 平展张量为向量
        x = x.view(-1, 256 * 8 * 8)
        
        # 全连接层
        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout(x)
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.dropout(x)
        x = self.fc3(x)
        
        return F.softmax(x, dim=1)


class ImageDataset(Dataset):
    """用于训练CNN的数据集类"""
    def __init__(self, image_dir, labels_file, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        
        # 加载标签文件(文件名,标签)
        self.labels = {}
        with open(labels_file, 'r') as f:
            for line in f:
                filename, label = line.strip().split(',')
                self.labels[filename] = int(label)
        
        # 获取所有图像文件名
        self.filenames = list(self.labels.keys())
    
    def __len__(self):
        return len(self.filenames)
    
    def __getitem__(self, idx):
        # 加载图像
        filename = self.filenames[idx]
        img_path = os.path.join(self.image_dir, filename)
        image = Image.open(img_path).convert('RGB')
        
        # 应用变换
        if self.transform:
            image = self.transform(image)
        
        # 获取标签
        label = self.labels[filename]
        
        return image, label

class AnimeCNNTrainer:
    """训练动漫检测CNN模型的类"""
    def __init__(self, model_save_path='anime_classifier.pth'):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model = AnimeClassifier().to(self.device)
        self.model_save_path = model_save_path
        
        # 图像预处理
        self.transform = transforms.Compose([
            transforms.Resize((128, 128)),  # 调整大小到128x128
            transforms.RandomHorizontalFlip(),  # 随机水平翻转
            transforms.RandomRotation(10),  # 轻微随机旋转
            transforms.ColorJitter(brightness=0.1, contrast=0.1),  # 颜色增强
            transforms.ToTensor(),  # 转换为tensor
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # 标准化
        ])
        
        # 用于预测的预处理
        self.pred_transform = transforms.Compose([
            transforms.Resize((128, 128)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    
    def train(self, train_dir, labels_file, epochs=10, batch_size=32, learning_rate=0.001):
        """训练模型"""
        # 创建数据集和数据加载器
        dataset = ImageDataset(train_dir, labels_file, transform=self.transform)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=4)
        
        # 损失函数和优化器
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(self.model.parameters(), lr=learning_rate, weight_decay=1e-4)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=2)
        
        # 训练循环
        print(f"开始训练，使用设备: {self.device}")
        for epoch in range(epochs):
            running_loss = 0.0
            correct = 0
            total = 0
            
            for i, (inputs, labels) in enumerate(dataloader):
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                
                # 梯度归零
                optimizer.zero_grad()
                
                # 前向传播 + 反向传播 + 优化
                outputs = self.model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                
                # 统计
                running_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
                
                # 打印统计信息
                if i % 10 == 9:
                    print(f'[Epoch {epoch + 1}, Batch {i + 1}] Loss: {running_loss / 10:.3f}, '
                          f'Accuracy: {100 * correct / total:.2f}%')
                    scheduler.step(running_loss / 10)
                    running_loss = 0.0
            
            # 每个epoch结束后计算整体准确率
            accuracy = 100 * correct / total
            print(f"Epoch {epoch + 1} finished. Accuracy: {accuracy:.2f}%")
        
        print("训练完成！")
        
        # 保存模型
        torch.save(self.model.state_dict(), self.model_save_path)
        print(f"模型已保存到 {self.model_save_path}")
    
    def load_model(self):
        """加载已训练好的模型"""
        if os.path.exists(self.model_save_path):
            self.model.load_state_dict(torch.load(self.model_save_path, map_location=self.device))
            self.model.eval()  # 设置为评估模式
            print(f"已加载训练好的模型 {self.model_save_path}")
            return True
        else:
            print(f"模型文件 {self.model_save_path} 不存在！")
            return False
    
    def predict(self, image):
        """对单个图像进行预测"""
        if isinstance(image, np.ndarray):
            # 如果是numpy数组，转换为PIL图像
            image = Image.fromarray(np.uint8(image))
        elif isinstance(image, bytes):
            # 如果是字节数据，转换为PIL图像
            image = Image.open(BytesIO(image)).convert('RGB')
        
        # 应用预处理
        image_tensor = self.pred_transform(image).unsqueeze(0).to(self.device)
        
        # 进行预测
        with torch.no_grad():
            outputs = self.model(image_tensor)
            _, predicted = torch.max(outputs, 1)
            
            # 返回预测结果和置信度
            confidence = outputs[0][predicted.item()].item()
            is_real = predicted.item() == 1  # 1表示真实图像，0表示动漫图像
            
            return is_real, confidence

class EnhancedImageScraper:
    def __init__(self, search_key, download_path, num_pages, debug_mode=False, filter_anime=True, confidence_threshold=0.7):
        self.search_key = search_key
        self.download_path = download_path
        self.num_pages = num_pages
        self.image_hashes = set()  # 用于存储图片哈希值，避免重复
        self.debug_mode = debug_mode
        self.filter_anime = filter_anime
        self.confidence_threshold = confidence_threshold
        
        # 初始化动漫分类器
        if filter_anime:
            self.anime_classifier = AnimeCNNTrainer()
            model_loaded = self.anime_classifier.load_model()
            if not model_loaded:
                print("警告：无法加载动漫分类器模型，将不过滤动漫图像")
                self.filter_anime = False
        
        # 设置日志
        logging.basicConfig(
            level=logging.DEBUG if debug_mode else logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # 创建下载目录
        self.search_key_path = os.path.join(download_path, re.sub(r'[\\/*?:"<>|]', "", search_key))
        if not os.path.exists(self.search_key_path):
            os.makedirs(self.search_key_path)
        
        # 设置Chrome选项
        self.options = Options()
        # 不使用无头模式，便于观察和调试
        # self.options.add_argument('--headless')
        self.options.add_argument('--disable-blink-features=AutomationControlled')
        self.options.add_experimental_option('excludeSwitches', ['enable-automation'])
        self.options.add_experimental_option('useAutomationExtension', False)
        self.options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    
    def scrape_images(self):
        print(f"开始爬取关键词 '{self.search_key}' 的图片...")
        
        # 初始化WebDriver
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=self.options)
        
        # 使用CDP命令绕过WebDriver检测
        driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
            'source': '''
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                })
            '''
        })
        
        try:
            # 直接访问Google图片搜索
            search_url = f"https://www.google.com/search?q={self.search_key}&tbm=isch"
            driver.get(search_url)
            
            print("等待页面加载...")
            time.sleep(5)  # 等待页面初始加载
            
            # 滚动加载更多图片
            for i in range(self.num_pages):
                print(f"滚动页面... ({i+1}/{self.num_pages})")
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(random.uniform(1.5, 3.0))
            
            # 使用简单的方法: 直接获取所有<img>标签
            print("查找所有图片元素...")
            img_elements = driver.find_elements(By.TAG_NAME, "img")
            print(f"找到 {len(img_elements)} 个图片元素")
            
            # 收集图片URL
            image_urls = []
            print("收集图片URL...")
            
            for i, img in enumerate(img_elements):
                try:
                    # 获取src属性
                    src = img.get_attribute("src")
                    
                    # 过滤掉非http开头的URL和小图标
                    if src and src.startswith("http") and not src.endswith(".gif"):
                        # 尝试获取图片尺寸
                        width = img.get_attribute("width")
                        height = img.get_attribute("height")
                        
                        # 如果能拿到尺寸，过滤掉小图片(通常是图标)
                        if width and height:
                            if int(width) < 50 or int(height) < 50:
                                continue
                        
                        print(f"收集到图片URL: {src[:50]}...")
                        image_urls.append(src)
                except Exception as e:
                    print(f"处理图片元素时出错: {str(e)}")
            
            print(f"总共收集到 {len(image_urls)} 个图片URL")
            
            # 下载图片
            self.download_images(image_urls)
            
        except Exception as e:
            print(f"爬虫过程中出错: {str(e)}")
        finally:
            driver.quit()
    
    def calculate_image_hash(self, image_data):
        try:
            # 使用PIL打开图片
            img = Image.open(BytesIO(image_data))
            
            # 缩放到32x32，并转为灰度图
            img = img.resize((32, 32), Image.LANCZOS).convert('L')
            
            # 计算DCT
            pixels = np.array(img.getdata(), dtype=np.float32).reshape((32, 32))
            dct = np.fft.fft2(pixels)
            
            # 取左上角8x8的DCT系数
            dctlowfreq = dct[:8, :8]
            
            # 计算均值
            avg = dctlowfreq.mean()
            
            # 计算哈希值
            phash = 0
            diff_bit = 1
            for i in range(8):
                for j in range(8):
                    if dctlowfreq[i, j] > avg:
                        phash |= diff_bit
                    diff_bit <<= 1
                    
            return hex(phash)[2:]
            
        except Exception as e:
            print(f"计算图片哈希失败: {str(e)}")
            return None
    
    def download_images(self, image_urls):
        """下载图片，过滤掉重复图片和动漫图片"""
        if not image_urls:
            logging.info("没有找到可下载的图片URL")
            return
        
        logging.info(f"开始下载和筛选 {len(image_urls)} 张图片...")
        downloaded_count = 0
        duplicate_count = 0
        anime_count = 0
        failed_count = 0
        low_confidence_count = 0
        
        for i, url in enumerate(image_urls):
            try:
                logging.info(f"处理图片 {i+1}/{len(image_urls)}")
                
                # 设置请求头
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': 'https://www.google.com/',
                    'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'
                }
                
                # 尝试获取未压缩的原始URL（在Google图片中）
                original_url = self._try_get_original_url(url)
                download_url = original_url if original_url else url
                
                # 下载图片
                try:
                    response = requests.get(download_url, headers=headers, timeout=10)
                except:
                    # 如果原始URL失败，尝试使用原始的缩略图URL
                    if original_url:
                        logging.info(f"原始URL访问失败，尝试缩略图URL...")
                        response = requests.get(url, headers=headers, timeout=10)
                    else:
                        raise
                
                # 检查是否为图片内容
                content_type = response.headers.get('Content-Type', '')
                if not content_type.startswith('image/'):
                    logging.info(f"URL {i+1}/{len(image_urls)} 返回的不是图片内容 (Content-Type: {content_type}), 跳过")
                    failed_count += 1
                    continue
                
                if response.status_code == 200:
                    image_data = response.content
                    
                    # 计算图片哈希，检查是否重复
                    img_hash = self.calculate_image_hash(image_data)
                    if not img_hash:
                        logging.info(f"无法计算图片 {i+1}/{len(image_urls)} 的哈希值，跳过")
                        failed_count += 1
                        continue
                        
                    if img_hash in self.image_hashes:
                        logging.info(f"图片 {i+1}/{len(image_urls)} 与已下载图片重复，跳过")
                        duplicate_count += 1
                        continue
                    
                    # 使用CNN检测是否为动漫图像
                    if self.filter_anime:
                        try:
                            is_real, confidence = self.anime_classifier.predict(image_data)

                            if not is_real:
                                logging.info(f"图片 {i+1}/{len(image_urls)} 被识别为动漫图像(置信度:{confidence:.4f})，跳过")
                                anime_count += 1
                                continue
                                
                            if confidence < self.confidence_threshold:
                                logging.info(f"图片 {i+1}/{len(image_urls)} 被识别为真实图像但置信度过低({confidence:.4f} < {self.confidence_threshold})，跳过")
                                low_confidence_count += 1
                                continue
                                
                            logging.info(f"图片 {i+1}/{len(image_urls)} 被识别为真实图像(置信度:{confidence:.4f})")
                        except Exception as e:
                            logging.error(f"动漫检测失败: {str(e)}")
                    
                    # 确定扩展名
                    if download_url.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                        extension = download_url.split('.')[-1].lower()
                        if '?' in extension:
                            extension = extension.split('?')[0]
                    else:
                        extension = 'jpg'
                    
                    file_name = f"{downloaded_count + 1}"
                    file_path = os.path.join(self.search_key_path, f"{file_name}.{extension}")
                    
                    # 保存图片
                    with open(file_path, 'wb') as f:
                        f.write(image_data)
                    
                    # 添加哈希值到集合中，避免重复
                    self.image_hashes.add(img_hash)
                    
                    logging.info(f"下载图片 {i+1}/{len(image_urls)} 成功，保存为 {file_name}.{extension}")
                    downloaded_count += 1
                else:
                    logging.info(f"下载图片 {i+1}/{len(image_urls)} 失败: 状态码 {response.status_code}")
                    failed_count += 1
                
                # 随机延迟
                time.sleep(random.uniform(0.3, 1.0))
                
            except Exception as e:
                logging.error(f"下载图片 {i+1}/{len(image_urls)} 时出错: {str(e)}")
                failed_count += 1
        
        logging.info(f"下载完成，共成功下载 {downloaded_count} 张图片")
        logging.info(f"过滤掉 {duplicate_count} 张重复图片，{anime_count} 张动漫图片，{low_confidence_count} 张低置信度图片，{failed_count} 张失败")
        logging.info(f"所有图片保存在 {self.search_key_path}")

    def _try_get_original_url(self, thumbnail_url):
        try:
            # 尝试多种可能的参数模式
            params = ["imgurl=", "imgrefurl=", "src="]
            
            for param in params:
                if param in thumbnail_url:
                    # 获取参数值
                    start_idx = thumbnail_url.index(param) + len(param)
                    end_idx = thumbnail_url.find("&", start_idx)
                    if end_idx == -1:
                        end_idx = len(thumbnail_url)
                    # 提取并解码URL
                    original_url = thumbnail_url[start_idx:end_idx]
                    # URL解码
                    import urllib.parse
                    original_url = urllib.parse.unquote(original_url)
                    # 确保是有效的URL
                    if original_url.startswith("http"):
                        logging.debug(f"找到原始URL: {original_url}")
                        return original_url
            
            return None
        except Exception as e:
            logging.debug(f"提取原始URL失败: {str(e)}")
            return None

class DatasetPreparer:
    """帮助准备训练数据集的工具类"""
    
    def __init__(self, output_dir="./dataset"):
        self.output_dir = output_dir
        # 创建必要的目录
        os.makedirs(os.path.join(output_dir, "train"), exist_ok=True)
        os.makedirs(os.path.join(output_dir, "val"), exist_ok=True)
        
        # 创建标签文件
        self.train_labels_file = os.path.join(output_dir, "train_labels.txt")
        self.val_labels_file = os.path.join(output_dir, "val_labels.txt")
        
        # 打开标签文件准备写入
        self.train_labels = open(self.train_labels_file, 'w')
        self.val_labels = open(self.val_labels_file, 'w')
    
    def add_images(self, image_dir, label, val_split=0.2):

        # 获取目录中的所有图像
        image_files = [f for f in os.listdir(image_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
        
        # 打乱图像顺序
        random.shuffle(image_files)
        
        # 确定训练集和验证集的分割点
        split_idx = int(len(image_files) * (1 - val_split))
        train_files = image_files[:split_idx]
        val_files = image_files[split_idx:]
        
        print(f"处理{image_dir}中的图像，标签={label}...")
        print(f"训练集: {len(train_files)}张，验证集: {len(val_files)}张")
        
        # 处理训练集图像
        self._process_files(train_files, image_dir, os.path.join(self.output_dir, "train"), label, self.train_labels)
        
        # 处理验证集图像
        self._process_files(val_files, image_dir, os.path.join(self.output_dir, "val"), label, self.val_labels)
    
    def _process_files(self, files, source_dir, target_dir, label, label_file):
        """处理图像文件：复制到目标目录并添加标签"""
        for i, filename in enumerate(files):
            try:
                # 读取原始图像
                src_path = os.path.join(source_dir, filename)
                img = Image.open(src_path).convert('RGB')
                
                # 创建新文件名 (使用前缀区分不同来源的图像)
                prefix = "anime_" if label == 0 else "real_"
                new_filename = f"{prefix}{i:05d}.jpg"
                dst_path = os.path.join(target_dir, new_filename)
                
                # 保存图像
                img.save(dst_path)
                
                # 写入标签文件
                label_file.write(f"{new_filename},{label}\n")
                
                if (i + 1) % 100 == 0:
                    print(f"已处理 {i + 1}/{len(files)} 个图像")
                
            except Exception as e:
                print(f"处理图像 {filename} 失败: {str(e)}")
    
    def close(self):
        """关闭标签文件"""
        self.train_labels.close()
        self.val_labels.close()

def train_anime_classifier(dataset_dir="./dataset", model_save_path="anime_classifier.pth", epochs=10):
    """训练动漫图像分类器"""
    trainer = AnimeCNNTrainer(model_save_path=model_save_path)
    trainer.train(
        train_dir=os.path.join(dataset_dir, "train"),
        labels_file=os.path.join(dataset_dir, "train_labels.txt"),
        epochs=epochs,
        batch_size=32
    )
    print(f"模型已保存到 {model_save_path}")
    return model_save_path

# 在这里修改训练数据集的文件夹地址
def prepare_dataset_example():
    preparer = DatasetPreparer(output_dir="./dataset")
    # 添加动漫图像 (标签 = 0)
    preparer.add_images("/Users/uestczr/Desktop/computer vision/动画图片", label=0)
    # 添加真实图像 (标签 = 1)
    preparer.add_images("/Users/uestczr/Desktop/computer vision/真实图片", label=1)
    preparer.close()
    print("数据集准备完成！")

# 在此处修改关键词和页面数
def main():
    search_key = "工人"  # 搜索关键词
    num_pages = 5       # 滚动页面次数
    download_path = "./images" 
    debug_mode = True
    
    # 配置过滤选项
    filter_anime = True  # 是否过滤动漫图像
    confidence_threshold = 0.8  # 动漫检测的置信度阈值
    
    # 确保下载目录存在
    if not os.path.exists(download_path):
        os.makedirs(download_path)
    
    # 爬取图片
    scraper = EnhancedImageScraper(
        search_key=search_key, 
        download_path=download_path, 
        num_pages=num_pages, 
        debug_mode=debug_mode,
        filter_anime=filter_anime,
        confidence_threshold=confidence_threshold
    )
    scraper.scrape_images()

if __name__ == "__main__":

    prepare_dataset_example()
    train_anime_classifier(epochs=5)
    
    main()