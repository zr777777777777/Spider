import os
import time
import re
import hashlib
import random
import requests
import numpy as np
from io import BytesIO
from PIL import Image
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms

class AnimeClassifier(nn.Module):
    def __init__(self):
        super(AnimeClassifier, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        self.conv2 = nn.Sequential(
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        self.conv3 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        self.conv4 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        
        self.fc1 = nn.Linear(256 * 8 * 8, 512)
        self.bn1 = nn.BatchNorm1d(512)
        self.fc2 = nn.Linear(512, 128)
        self.bn2 = nn.BatchNorm1d(128)
        self.fc3 = nn.Linear(128, 2)
        
        self.dropout = nn.Dropout(0.5)
        
        self._initialize_weights()
    
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        
        x = x.view(-1, 256 * 8 * 8)
        
        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout(x)
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.dropout(x)
        x = self.fc3(x)
        
        return F.softmax(x, dim=1)

class ImageDataset(Dataset):
    def __init__(self, image_dir, labels_file, transform=None):
        self.image_dir = image_dir
        self.transform = transform
        
        self.labels = {}
        with open(labels_file, 'r') as f:
            for line in f:
                filename, label = line.strip().split(',')
                self.labels[filename] = int(label)
        
        self.filenames = list(self.labels.keys())
    
    def __len__(self):
        return len(self.filenames)
    
    def __getitem__(self, idx):
        filename = self.filenames[idx]
        img_path = os.path.join(self.image_dir, filename)
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        label = self.labels[filename]
        
        return image, label

class AnimeCNNTrainer:
    def __init__(self, model_save_path='anime_classifier.pth'):
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model = AnimeClassifier().to(self.device)
        self.model_save_path = model_save_path
        
        self.transform = transforms.Compose([
            transforms.Resize((128, 128)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(10),
            transforms.ColorJitter(brightness=0.1, contrast=0.1),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        self.pred_transform = transforms.Compose([
            transforms.Resize((128, 128)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    
    def train(self, train_dir, labels_file, epochs=10, batch_size=32, learning_rate=0.001):
        dataset = ImageDataset(train_dir, labels_file, transform=self.transform)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=4)
        
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(self.model.parameters(), lr=learning_rate, weight_decay=1e-4)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=2)
        
        print(f"开始训练，使用设备: {self.device}")
        for epoch in range(epochs):
            running_loss = 0.0
            correct = 0
            total = 0
            
            for i, (inputs, labels) in enumerate(dataloader):
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                
                optimizer.zero_grad()
                
                outputs = self.model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                
                running_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
                
                if i % 10 == 9:
                    print(f'[Epoch {epoch + 1}, Batch {i + 1}] Loss: {running_loss / 10:.3f}, '
                          f'Accuracy: {100 * correct / total:.2f}%')
                    scheduler.step(running_loss / 10)
                    running_loss = 0.0
            
            accuracy = 100 * correct / total
            print(f"Epoch {epoch + 1} finished. Accuracy: {accuracy:.2f}%")
        
        print("训练完成！")
        
        self.save_model()
        print(f"模型已保存到 {self.model_save_path}")
    
    def save_model(self):
        torch.save(self.model.state_dict(), self.model_save_path)
    
    def load_model(self):
        if os.path.exists(self.model_save_path):
            self.model.load_state_dict(torch.load(self.model_save_path, map_location=self.device))
            self.model.eval()
            print(f"已加载训练好的模型 {self.model_save_path}")
            return True
        else:
            print(f"模型文件 {self.model_save_path} 不存在！")
            return False
    
    def predict(self, image):
        if isinstance(image, np.ndarray):
            image = Image.fromarray(np.uint8(image))
        elif isinstance(image, bytes):
            image = Image.open(BytesIO(image)).convert('RGB')
        
        image_tensor = self.pred_transform(image).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            outputs = self.model(image_tensor)
            _, predicted = torch.max(outputs, 1)
            
            confidence = outputs[0][predicted.item()].item()
            is_real = predicted.item() == 1
            
            return is_real, confidence

class EnhancedImageScraper:
    def __init__(self, search_key, download_path, num_pages, debug_mode=False, 
                 filter_anime=True, filter_duplicates=True, confidence_threshold=0.7,
                 model_path='anime_classifier.pth'):
        self.search_key = search_key
        self.download_path = download_path
        self.num_pages = num_pages
        self.image_hashes = set()
        self.debug_mode = debug_mode
        self.filter_anime = filter_anime
        self.filter_duplicates = filter_duplicates
        self.confidence_threshold = confidence_threshold
        self.model_path = model_path
        
        if filter_anime:
            self.anime_classifier = AnimeCNNTrainer(model_save_path=model_path)
            model_loaded = self.anime_classifier.load_model()
            if not model_loaded:
                print("警告：无法加载动漫分类器模型，将不过滤动漫图像")
                self.filter_anime = False
        
        logging.basicConfig(
            level=logging.DEBUG if debug_mode else logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        self.search_key_path = os.path.join(download_path, re.sub(r'[\\/*?:"<>|]', "", search_key))
        if not os.path.exists(self.search_key_path):
            os.makedirs(self.search_key_path)
        
        self.options = Options()
        self.options.add_argument('--disable-blink-features=AutomationControlled')
        self.options.add_experimental_option('excludeSwitches', ['enable-automation'])
        self.options.add_experimental_option('useAutomationExtension', False)
        self.options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    
    def scrape_images(self):
        print(f"开始爬取关键词 '{self.search_key}' 的图片...")
        
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=self.options)
        
        driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
            'source': '''
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                })
            '''
        })
        
        try:
            search_url = f"https://www.google.com/search?q={self.search_key}&tbm=isch"
            driver.get(search_url)
            
            print("等待页面加载...")
            time.sleep(5)
            
            for i in range(self.num_pages):
                print(f"滚动页面... ({i+1}/{self.num_pages})")
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(random.uniform(1.5, 3.0))
            
            print("查找所有图片元素...")
            img_elements = driver.find_elements(By.TAG_NAME, "img")
            print(f"找到 {len(img_elements)} 个图片元素")
            
            image_urls = []
            print("收集图片URL...")
            
            for i, img in enumerate(img_elements):
                try:
                    src = img.get_attribute("src")
                    
                    if src and src.startswith("http") and not src.endswith(".gif"):
                        width = img.get_attribute("width")
                        height = img.get_attribute("height")
                        
                        if width and height:
                            if int(width) < 50 or int(height) < 50:
                                continue
                        
                        print(f"收集到图片URL: {src[:50]}...")
                        image_urls.append(src)
                except Exception as e:
                    print(f"处理图片元素时出错: {str(e)}")
            
            print(f"总共收集到 {len(image_urls)} 个图片URL")
            
            self.download_images(image_urls)
            
        except Exception as e:
            print(f"爬虫过程中出错: {str(e)}")
        finally:
            driver.quit()
    
    def calculate_image_hash(self, image_data):
        try:
            img = Image.open(BytesIO(image_data))
            
            img = img.resize((32, 32), Image.LANCZOS).convert('L')
            
            pixels = np.array(img.getdata(), dtype=np.float32).reshape((32, 32))
            dct = np.fft.fft2(pixels)
            
            dctlowfreq = dct[:8, :8]
            
            avg = dctlowfreq.mean()
            
            phash = 0
            diff_bit = 1
            for i in range(8):
                for j in range(8):
                    if dctlowfreq[i, j] > avg:
                        phash |= diff_bit
                    diff_bit <<= 1
                    
            return hex(phash)[2:]
            
        except Exception as e:
            print(f"计算图片哈希失败: {str(e)}")
            return None
    
    def download_images(self, image_urls):
        if not image_urls:
            logging.info("没有找到可下载的图片URL")
            return
        
        logging.info(f"开始下载和筛选 {len(image_urls)} 张图片...")
        downloaded_count = 0
        duplicate_count = 0
        anime_count = 0
        failed_count = 0
        low_confidence_count = 0
        
        for i, url in enumerate(image_urls):
            try:
                logging.info(f"处理图片 {i+1}/{len(image_urls)}")
                
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': 'https://www.google.com/',
                    'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'
                }
                
                original_url = self._try_get_original_url(url)
                download_url = original_url if original_url else url
                
                try:
                    response = requests.get(download_url, headers=headers, timeout=10)
                except:
                    if original_url:
                        logging.info(f"原始URL访问失败，尝试缩略图URL...")
                        response = requests.get(url, headers=headers, timeout=10)
                    else:
                        raise
                
                content_type = response.headers.get('Content-Type', '')
                if not content_type.startswith('image/'):
                    logging.info(f"URL {i+1}/{len(image_urls)} 返回的不是图片内容 (Content-Type: {content_type}), 跳过")
                    failed_count += 1
                    continue
                
                if response.status_code == 200:
                    image_data = response.content
                    
                    if self.filter_duplicates:
                        img_hash = self.calculate_image_hash(image_data)
                        if not img_hash:
                            logging.info(f"无法计算图片 {i+1}/{len(image_urls)} 的哈希值，跳过")
                            failed_count += 1
                            continue
                            
                        if img_hash in self.image_hashes:
                            logging.info(f"图片 {i+1}/{len(image_urls)} 与已下载图片重复，跳过")
                            duplicate_count += 1
                            continue
                        
                        self.image_hashes.add(img_hash)
                    
                    if self.filter_anime:
                        try:
                            is_real, confidence = self.anime_classifier.predict(image_data)

                            if not is_real:
                                logging.info(f"图片 {i+1}/{len(image_urls)} 被识别为动漫图像(置信度:{confidence:.4f})，跳过")
                                anime_count += 1
                                continue
                                
                            if confidence < self.confidence_threshold:
                                logging.info(f"图片 {i+1}/{len(image_urls)} 被识别为真实图像但置信度过低({confidence:.4f} < {self.confidence_threshold})，跳过")
                                low_confidence_count += 1
                                continue
                                
                            logging.info(f"图片 {i+1}/{len(image_urls)} 被识别为真实图像(置信度:{confidence:.4f})")
                        except Exception as e:
                            logging.error(f"动漫检测失败: {str(e)}")
                    
                    if download_url.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                        extension = download_url.split('.')[-1].lower()
                        if '?' in extension:
                            extension = extension.split('?')[0]
                    else:
                        extension = 'jpg'
                    
                    file_name = f"{downloaded_count + 1}"
                    file_path = os.path.join(self.search_key_path, f"{file_name}.{extension}")
                    
                    with open(file_path, 'wb') as f:
                        f.write(image_data)
                    
                    logging.info(f"下载图片 {i+1}/{len(image_urls)} 成功，保存为 {file_name}.{extension}")
                    downloaded_count += 1
                else:
                    logging.info(f"下载图片 {i+1}/{len(image_urls)} 失败: 状态码 {response.status_code}")
                    failed_count += 1
                
                time.sleep(random.uniform(0.3, 1.0))
                
            except Exception as e:
                logging.error(f"下载图片 {i+1}/{len(image_urls)} 时出错: {str(e)}")
                failed_count += 1
        
        logging.info(f"下载完成，共成功下载 {downloaded_count} 张图片")
        if self.filter_duplicates:
            logging.info(f"过滤掉 {duplicate_count} 张重复图片")
        if self.filter_anime:
            logging.info(f"过滤掉 {anime_count} 张动漫图片，{low_confidence_count} 张低置信度图片")
        logging.info(f"下载失败: {failed_count} 张")
        logging.info(f"所有图片保存在 {self.search_key_path}")

    def _try_get_original_url(self, thumbnail_url):
        try:
            params = ["imgurl=", "imgrefurl=", "src="]
            
            for param in params:
                if param in thumbnail_url:
                    start_idx = thumbnail_url.index(param) + len(param)
                    end_idx = thumbnail_url.find("&", start_idx)
                    if end_idx == -1:
                        end_idx = len(thumbnail_url)
                    original_url = thumbnail_url[start_idx:end_idx]
                    import urllib.parse
                    original_url = urllib.parse.unquote(original_url)
                    if original_url.startswith("http"):
                        logging.debug(f"找到原始URL: {original_url}")
                        return original_url
            
            return None
        except Exception as e:
            logging.debug(f"提取原始URL失败: {str(e)}")
            return None

class DatasetPreparer:
    def __init__(self, output_dir="./dataset"):
        self.output_dir = output_dir
        os.makedirs(os.path.join(output_dir, "train"), exist_ok=True)
        os.makedirs(os.path.join(output_dir, "val"), exist_ok=True)
        
        self.train_labels_file = os.path.join(output_dir, "train_labels.txt")
        self.val_labels_file = os.path.join(output_dir, "val_labels.txt")
        
        self.train_labels = open(self.train_labels_file, 'w')
        self.val_labels = open(self.val_labels_file, 'w')
    
    def add_images(self, image_dir, label, val_split=0.2):
        image_files = [f for f in os.listdir(image_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
        
        random.shuffle(image_files)
        
        split_idx = int(len(image_files) * (1 - val_split))
        train_files = image_files[:split_idx]
        val_files = image_files[split_idx:]
        
        print(f"处理{image_dir}中的图像，标签={label}...")
        print(f"训练集: {len(train_files)}张，验证集: {len(val_files)}张")
        
        self._process_files(train_files, image_dir, os.path.join(self.output_dir, "train"), label, self.train_labels)
        
        self._process_files(val_files, image_dir, os.path.join(self.output_dir, "val"), label, self.val_labels)
    
    def _process_files(self, files, source_dir, target_dir, label, label_file):
        for i, filename in enumerate(files):
            try:
                src_path = os.path.join(source_dir, filename)
                img = Image.open(src_path).convert('RGB')
                
                prefix = "anime_" if label == 0 else "real_"
                new_filename = f"{prefix}{i:05d}.jpg"
                dst_path = os.path.join(target_dir, new_filename)
                
                img.save(dst_path)
                
                label_file.write(f"{new_filename},{label}\n")
                
                if (i + 1) % 100 == 0:
                    print(f"已处理 {i + 1}/{len(files)} 个图像")
                
            except Exception as e:
                print(f"处理图像 {filename} 失败: {str(e)}")
    
    def close(self):
        self.train_labels.close()
        self.val_labels.close()

def train_anime_classifier(dataset_dir="./dataset", model_save_path="anime_classifier.pth", epochs=10):
    trainer = AnimeCNNTrainer(model_save_path=model_save_path)
    trainer.train(
        train_dir=os.path.join(dataset_dir, "train"),
        labels_file=os.path.join(dataset_dir, "train_labels.txt"),
        epochs=epochs,
        batch_size=32
    )
    print(f"模型已保存到 {model_save_path}")
    return model_save_path

def prepare_dataset_example(anime_dir, real_dir, output_dir="./dataset"):
    preparer = DatasetPreparer(output_dir=output_dir)
    preparer.add_images(anime_dir, label=0)
    preparer.add_images(real_dir, label=1)
    preparer.close()
    print("数据集准备完成！")

def main(search_key="工人", num_pages=5, download_path="./images", debug_mode=True, 
         filter_anime=True, filter_duplicates=True, confidence_threshold=0.8,
         model_path="anime_classifier.pth"):
    
    if not os.path.exists(download_path):
        os.makedirs(download_path)
    
    scraper = EnhancedImageScraper(
        search_key=search_key, 
        download_path=download_path, 
        num_pages=num_pages, 
        debug_mode=debug_mode,
        filter_anime=filter_anime,
        filter_duplicates=filter_duplicates,
        confidence_threshold=confidence_threshold,
        model_path=model_path
    )
    scraper.scrape_images()

if __name__ == "__main__":
    # 模型训练部分 - 只需运行一次，后面调用就把这个地方注释掉
    # anime_dir = "/Users/uestczr/Desktop/computer vision/Spider/animated pictures"
    # real_dir = "/Users/uestczr/Desktop/computer vision/Spider/true pictures"
    # prepare_dataset_example(anime_dir, real_dir)
    # train_anime_classifier(epochs=20)
    
    # 爬虫配置
    search_key = "吸烟"
    num_pages = 5
    download_path = "./images"
    debug_mode = True
    
    # 过滤选项
    filter_anime = True      # 是否过滤动漫图像
    filter_duplicates = True # 是否过滤重复图像
    confidence_threshold = 0.8
    model_path = "anime_classifier.pth"  # 预训练模型路径
    
    main(
        search_key=search_key,
        num_pages=num_pages,
        download_path=download_path,
        debug_mode=debug_mode,
        filter_anime=filter_anime,
        filter_duplicates=filter_duplicates,
        confidence_threshold=confidence_threshold,
        model_path=model_path
    )